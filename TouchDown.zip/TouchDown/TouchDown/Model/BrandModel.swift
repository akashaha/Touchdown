//
//  BrandModel.swift
//  TouchDown
//
//  Created by Arman Akash on 10/15/24.
//

import Foundation

struct Brand: Codable, Identifiable {
  let id: Int
  let image: String
}
