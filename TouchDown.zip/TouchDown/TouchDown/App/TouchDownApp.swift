//
//  TouchDownApp.swift
//  TouchDown
//
//  Created by Arman Akash on 10/15/24.
//

import SwiftUI

@main
struct TouchDownApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(Shop())
        }
    }
}
